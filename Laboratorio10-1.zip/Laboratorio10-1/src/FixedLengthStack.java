
public class FixedLengthStack implements ISimpleStack {
   private char[] dadosDaPilha;
   private int topo;
   
   public FixedLengthStack(int tamanho) {
	   this.dadosDaPilha = new char[tamanho];
	   this.topo = 0;
   }
   
   public void push(char dado) {
	   if(isFull()) {
		   System.out.println("Pilha cheia!");
		   return;
	   }
	   this.dadosDaPilha[topo++] = dado;
   }
   
   public char pop() {
	   if(isEmpty()) {
		   System.out.println("Pilha vazia!");
		   return (char) 0;
	   }
	   return this.dadosDaPilha[--topo];
   }
   
   public boolean isEmpty() {
	   return this.topo == 0;
   }
   
   public boolean isFull() {
	   return this.topo == this.dadosDaPilha.length;
   }
   
   public void reset() {
	  for(int i = 0; i < this.dadosDaPilha.length; i++) {
		  this.dadosDaPilha[i] = '\u0000';
		  this.topo = 0;
	  }   
  }
   
   public char peek() {
	   char aux;
	   aux = this.dadosDaPilha[topo-1];
	   return aux;
   }
   
   public int size() {
	   return this.topo;
   }
   
   public void imprime() {
	   for(int i = 0; i < this.topo; i++) {
		   System.out.println(this.dadosDaPilha[i]);
	   }
   }
   
}
