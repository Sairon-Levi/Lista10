
public class ISimpleStackDemo {

	public static void main(String[] args) {
		ISimpleStack fixed = new FixedLengthStack(5);
		ISimpleStack dynamic = new DynamicStack(5);
		
		boolean aux = fixed.isEmpty();
		System.out.println(aux);
		
		aux = fixed.isFull();
		System.out.println(aux);
		
		
		
		for(int i = 0; i < 5; i++) {
			fixed.push('3');
		}
		
		aux = fixed.isEmpty();
		System.out.println(aux);
		
		aux = fixed.isFull();
		System.out.println(aux);
		
		System.out.println(fixed.peek());
		
	    char pop = fixed.pop();
	    
	    System.out.println("Info: "+pop);
	    
	    fixed.imprime();
	    
	    System.out.println(fixed.size());
	    
	    fixed.reset();
	    
	    System.out.println(fixed.isEmpty());
	    System.out.println(fixed.isFull());
	    
		fixed.imprime();
	}
	
}
